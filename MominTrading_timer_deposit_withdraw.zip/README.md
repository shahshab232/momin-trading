# Momin Trading — starter website

A Flask starter project with a responsive landing page, account registration/login, demo-only Buy/Sell order logging, wallet request forms, and an admin review page.

## Important limitations
- This is **not a live trading platform**. Orders are saved as demo records only.
- Deposit/withdrawal forms only create requests. No Easypaisa, JazzCash, bank, or USDT payment is processed.
- Admin approval does not change user balances. Verify payments manually and get professional security/legal review before handling real money.
- Demo prices shown on the site are illustrative, not live market data or financial advice.

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run `python -m venv .venv`
4. Activate the virtual environment.
5. Run `pip install -r requirements.txt`
6. Run `python app.py` locally
7. Open `http://127.0.0.1:5000`

## Admin starter login
Username: `admin`
Password: `ChangeMe123!`

Change this immediately, set a strong `SECRET_KEY`, disable debug mode, and add CSRF protection, rate limiting, secure cookies, database migrations/backups, audit logs, and professional security review before deployment. Do not deploy this starter with the default admin credentials.

## Hosting
This Flask app cannot run directly inside Google Sites. Deploy it on a Python-capable host, then link to it from Google Sites if desired. Google Search Console can request indexing, but cannot guarantee search ranking.


## Render deployment settings
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Set environment variable `SECRET_KEY` to a long random secret in your host dashboard.
- This starter uses SQLite; on hosts with temporary filesystems, database records may be lost on redeploy/restart. Use a managed persistent database before real users or real money.


Timer update: Demo timer choices are 5 seconds, 10 seconds, 1 minute, and 14 minutes. Deposit/withdrawal forms create manual review requests only. Real transfers require a compliant payment provider, backend verification, and any required licences/approvals. Trading remains demo-only and does not pay profits.
