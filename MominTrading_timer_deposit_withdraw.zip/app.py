from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os
from functools import wraps

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deployment")
DB = os.path.join(os.path.dirname(__file__), "momin_trading.db")

def connect():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL, balance REAL NOT NULL DEFAULT 10000,
            is_admin INTEGER NOT NULL DEFAULT 0)""")
        db.execute("""CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            kind TEXT NOT NULL, amount REAL NOT NULL, method TEXT NOT NULL,
            reference TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'Pending')""")
        db.execute("""CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            asset TEXT NOT NULL, side TEXT NOT NULL, amount REAL NOT NULL,
            mode TEXT NOT NULL DEFAULT 'Demo')""")
        admin = db.execute("SELECT id FROM users WHERE username='admin'").fetchone()
        if not admin:
            db.execute("INSERT INTO users (username,password,balance,is_admin) VALUES (?,?,?,1)",
                       ("admin", generate_password_hash("ChangeMe123!"), 10000))

init_db()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("is_admin"):
            flash("Admin access required.")
            return redirect(url_for("home"))
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        if len(username) < 3 or len(password) < 8:
            flash("Username must be 3+ characters and password 8+ characters.")
        else:
            try:
                with connect() as db:
                    db.execute("INSERT INTO users (username,password) VALUES (?,?)",
                               (username, generate_password_hash(password)))
                flash("Account created. Please log in.")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That username is already taken.")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        with connect() as db:
            user = db.execute("SELECT * FROM users WHERE username=?",
                              (request.form.get("username","").strip(),)).fetchone()
        if user and check_password_hash(user["password"], request.form.get("password","")):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["is_admin"] = bool(user["is_admin"])
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    with connect() as db:
        user = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
        trades = db.execute("SELECT * FROM trades WHERE user_id=? ORDER BY id DESC LIMIT 10",
                            (session["user_id"],)).fetchall()
        requests_list = db.execute("SELECT * FROM requests WHERE user_id=? ORDER BY id DESC LIMIT 10",
                                   (session["user_id"],)).fetchall()
    return render_template("dashboard.html", user=user, trades=trades, requests_list=requests_list)

@app.route("/trade", methods=["GET","POST"])
@login_required
def trade():
    if request.method == "POST":
        asset = request.form.get("asset","BTC/USD")
        side = request.form.get("side","Buy")
        try:
            amount = float(request.form.get("amount","0"))
        except ValueError:
            amount = 0
        if asset not in ["BTC/USD","ETH/USD","GOLD/USD"] or side not in ["Buy","Sell"] or not 1 <= amount <= 10000:
            flash("Choose a listed asset and an amount between $1 and $10,000.")
        else:
            with connect() as db:
                db.execute("INSERT INTO trades (user_id,asset,side,amount,mode) VALUES (?,?,?,?,?)",
                           (session["user_id"],asset,side,amount,"Demo"))
            flash("Demo order recorded. This does not place a real trade or generate real profit.")
            return redirect(url_for("trade"))
    return render_template("trade.html")

@app.route("/wallet", methods=["GET","POST"])
@login_required
def wallet():
    if request.method == "POST":
        kind = request.form.get("kind")
        method = request.form.get("method")
        reference = request.form.get("reference","").strip()[:120]
        try:
            amount = float(request.form.get("amount","0"))
        except ValueError:
            amount = 0
        if kind not in ["Deposit","Withdrawal"] or method not in ["Easypaisa","JazzCash","USDT TRC20"] or not 1 <= amount <= 1000000:
            flash("Enter a valid amount, request type, and method.")
        else:
            with connect() as db:
                db.execute("INSERT INTO requests (user_id,kind,amount,method,reference) VALUES (?,?,?,?,?)",
                           (session["user_id"],kind,amount,method,reference))
            flash("Request submitted for admin review. No payment was processed.")
            return redirect(url_for("wallet"))
    with connect() as db:
        requests_list = db.execute("SELECT * FROM requests WHERE user_id=? ORDER BY id DESC",
                                   (session["user_id"],)).fetchall()
    return render_template("wallet.html", requests_list=requests_list)

@app.route("/admin", methods=["GET","POST"])
@login_required
@admin_required
def admin():
    if request.method == "POST":
        request_id = request.form.get("request_id")
        action = request.form.get("action")
        with connect() as db:
            item = db.execute("SELECT * FROM requests WHERE id=?", (request_id,)).fetchone()
            if item and item["status"] == "Pending" and action in ["Approve","Reject"]:
                # This starter intentionally does not move balances or claim a payment occurred.
                db.execute("UPDATE requests SET status=? WHERE id=?",
                           ("Approved for manual processing" if action == "Approve" else "Rejected", request_id))
        flash("Request status updated. Verify any real payment manually before acting.")
        return redirect(url_for("admin"))
    with connect() as db:
        requests_list = db.execute("""SELECT requests.*, users.username FROM requests
            JOIN users ON users.id=requests.user_id ORDER BY requests.id DESC""").fetchall()
        users = db.execute("SELECT id,username,balance FROM users ORDER BY id").fetchall()
    return render_template("admin.html", requests_list=requests_list, users=users)

@app.errorhandler(404)
def not_found(_):
    return render_template("404.html"), 404

if __name__ == "__main__":
    app.run(debug=True)
